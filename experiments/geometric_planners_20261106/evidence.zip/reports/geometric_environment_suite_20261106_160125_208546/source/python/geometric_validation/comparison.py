"""Read-only comparison of recorded flights, with raw samples and no smoothing."""
import html
import hashlib
import json
from pathlib import Path

import numpy as np


def render(folder):
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib import pyplot as plt
    from matplotlib.ticker import MaxNLocator

    folder=Path(folder).resolve()
    summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'))
    cfg=json.loads((folder/'config_frozen.json').read_text(encoding='utf-8'))
    colors={'bezier':'#007c91','hermite':'#b6417a','bspline':'#a66a00'}
    fig=plt.figure(figsize=(12,8),layout='constrained')
    world=fig.add_subplot(2,2,1,projection='3d')
    position=fig.add_subplot(2,2,2);attitude=fig.add_subplot(2,2,3);speed=fig.add_subplot(2,2,4)
    for item in summary['results']:
        method=item['method'];path=item.get('run_dir');color=colors[method]
        if not path:
            continue
        path=Path(path)
        rows=[json.loads(line) for line in (path/'samples.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
        rows=[r for r in rows if r.get('phase')=='TRACKING']
        if not rows:
            continue
        t=np.asarray([r['t'] for r in rows]);xyz=np.asarray([r['position'] for r in rows]);xyz[:,2]*=-1
        reference=np.asarray([r['reference']['p'] for r in rows]);reference[:,2]*=-1
        world.plot(*xyz.T,color=color,label=method)
        world.plot(*reference.T,color=color,linestyle='--',alpha=.5)
        position.plot(t,np.linalg.norm(xyz-reference,axis=1),color=color,label=method)
        attitude.plot(t,np.degrees([r['attitude_reference_error_rad'] for r in rows]),color=color,label=method)
        speed.plot(t,np.linalg.norm([r['velocity'] for r in rows],axis=1),color=color,label=method)
    points=np.array(cfg['comparison']['task']['points_ned']);points[:,2]*=-1
    world.scatter(*points.T,color='#222222',marker='x',s=35)
    world.set(xlabel='X (m)',ylabel='Y (m)',zlabel='Height (m)',title='Measured solid / reference dashed')
    world.set_box_aspect(np.maximum(np.ptp(points,axis=0),1.))
    world.zaxis.set_major_locator(MaxNLocator(nbins=3))
    position.axhline(cfg['limits']['position_error_m'],color='#333333',linestyle=':')
    attitude.axhline(np.degrees(cfg['limits']['attitude_error_rad']),color='#333333',linestyle=':')
    speed.axhline(cfg['comparison']['passage']['min_actual_speed_mps'],color='#777777',linestyle=':',label='via-point speed gate')
    for ax,label in ((position,'Position error (m)'),(attitude,'SO(3) reference error (deg)'),(speed,'Actual speed (m/s)')):
        ax.set(xlabel='Simulation time from release (s)',ylabel=label);ax.grid(alpha=.2)
        if ax.get_legend_handles_labels()[0]:ax.legend(fontsize=8)
    if world.get_legend_handles_labels()[0]:world.legend(fontsize=8)
    fig.savefig(folder/'comparison.png',dpi=160)
    fig.savefig(folder/'comparison.svg')
    plt.close(fig)
    def value(x):
        if x is True:return '通过'
        if x is False:return '未通过'
        if x is None:return '未运行 / 无记录'
        if isinstance(x,float):return f'{x:.4f}'
        return html.escape(str(x))
    headings=['方案','正常完成','位置/姿态','连续过点','审计','安全收尾','实际时间(s)','参考时间(s)','位置峰值(m)','姿态峰值(°)']
    keys=['method','normal_completion','tracking_passed','passage_passed','audit_passed','safe_cleanup','actual_time_s',
          'reference_time_s','position_peak_m','attitude_peak_deg']
    body=''.join('<tr>'+''.join('<td>'+value(r.get(k))+'</td>' for k in keys)+'</tr>' for r in summary['results'])
    links=''.join('<li>'+html.escape(r['method'])+': '+
        ('<a href="'+html.escape(str(Path(r['run_dir']).relative_to(folder)).replace('\\','/')+'/report.json')+'">report.json</a>'
         if r.get('run_dir') else value(r.get('error',r['status'])))+'</li>' for r in summary['results'])
    environment=summary.get('environment',cfg.get('comparison',{}).get('environment',{}))
    environment_label=html.escape(environment.get('label','E0 · 基准三维过点'))
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>三种轨迹 · 实测对比</title>
<style>body{font:15px sans-serif;margin:28px;color:#20242a;line-height:1.6}table{border-collapse:collapse;width:100%}
td,th{padding:7px 9px;border-bottom:1px solid #d7dce1;text-align:left}img{width:100%;max-width:1200px}a{color:#007486}</style>
<h1>三种轨迹 · 实测对比</h1><p>'''+environment_label+''' · 本批条件一致性：'''+value(summary['comparable_conditions'])+'''。</p>
<p>每方案一次开发覆盖。Bézier 与 Hermite 是等价换基，不作独立算法优劣结论。时间搜索只约束参考运动学，尚未自动搜索真实闭环的最快可行时间。</p>
<table><thead><tr>'''+''.join('<th>'+h+'</th>' for h in headings)+'''</tr></thead><tbody>'''+body+'''</tbody></table>
<p>实际时间含末端稳定保持，起飞、准备与降落另记。规划耗时见原始报告，含不同的首次导入开销，不直接排名。</p>
<img src="comparison.png" alt="原始飞行轨迹与误差"><p><a href="comparison.csv">完整 CSV</a> ·
<a href="summary.json">汇总 JSON</a> · <a href="comparison.svg">SVG 图</a> · <a href="design_frozen.json">冻结条件</a></p>
<ul>'''+links+'</ul></html>'
    (folder/'index.html').write_text(page,encoding='utf-8')
    plot_source=folder/'plot_source';plot_source.mkdir(exist_ok=True)
    (plot_source/'comparison.py').write_bytes(Path(__file__).read_bytes())
    inputs=[folder/'config_frozen.json',folder/'summary.json',folder/'comparison.csv']
    inputs += [Path(r['run_dir'])/'samples.jsonl' for r in summary['results'] if r.get('run_dir')]
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    provenance=dict(inputs={str(p):sha(p) for p in inputs},plot_source_sha256=sha(plot_source/'comparison.py'),
                    outputs={p:sha(folder/p) for p in ('index.html','comparison.png','comparison.svg')},
                    scope='Read-only rendering of recorded samples; no new flight, smoothing, sensor or camera evidence')
    (folder/'plot_provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
    return folder/'index.html'
