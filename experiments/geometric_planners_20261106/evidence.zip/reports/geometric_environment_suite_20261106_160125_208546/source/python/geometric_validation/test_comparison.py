"""Derived reports preserve raw evidence and accept relative campaign paths."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest

from .campaign import PLANNER_CONFIG
from .comparison import render


class ComparisonTests(unittest.TestCase):
    def test_relative_path_report_has_bound_plot_source_and_preserves_samples(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as tmp:
            folder=Path(tmp);flight=folder/'flights'/'synthetic';flight.mkdir(parents=True)
            (folder/'config_frozen.json').write_bytes(PLANNER_CONFIG.read_bytes())
            samples=flight/'samples.jsonl'
            rows=[dict(phase='TRACKING',t=t,position=[t,0,-5],velocity=[.8,0,0],
                       reference=dict(p=[t,0,-5]),attitude_reference_error_rad=0.) for t in (.1,.2)]
            samples.write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')
            before=hashlib.sha256(samples.read_bytes()).hexdigest()
            (folder/'summary.json').write_text(json.dumps(dict(results=[dict(method='bezier',run_dir=str(flight),
                normal_completion=False,reference_time_s=1.)],comparable_conditions=False)),encoding='utf-8')
            (folder/'comparison.csv').write_text('method\nbezier\n',encoding='utf-8')
            page=render(os.path.relpath(folder))
            self.assertIn('flights/synthetic/report.json',page.read_text(encoding='utf-8'))
            provenance=json.loads((folder/'plot_provenance.json').read_text(encoding='utf-8'))
            self.assertEqual(provenance['inputs'][str(samples)],before)
            self.assertEqual(hashlib.sha256(samples.read_bytes()).hexdigest(),before)
            self.assertTrue((folder/'comparison.png').is_file())
            self.assertTrue((folder/'plot_source'/'comparison.py').is_file())
