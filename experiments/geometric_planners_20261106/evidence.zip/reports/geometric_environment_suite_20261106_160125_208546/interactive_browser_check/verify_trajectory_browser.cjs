/* Local browser verification of recorded-data plots, including WebGL pixels. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('C:/Users/NAU/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {PNG}=require('C:/Users/NAU/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/pngjs');
const root=path.resolve(__dirname,'..');
const suite=path.join(root,'reports/geometric_environment_suite_20261106_160125_208546');
const output=path.join(suite,'interactive_browser_check');
fs.mkdirSync(output,{recursive:true});
const records=[],errors=[],remote=[];
async function settled(page){
  await page.waitForFunction(()=>window.trajectoryReady&&!window.trajectoryBusy&&!window.trajectoryError);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
}
async function click(page,selector){await page.locator(selector).click();await settled(page);}
async function screenshot(page,name){
  const bytes=await page.screenshot({path:path.join(output,name),fullPage:true});
  const png=PNG.sync.read(bytes),colors=[[0,124,145],[182,65,122],[180,107,5]],counts=[0,0,0];
  for(let i=0;i<png.data.length;i+=4){
    for(let k=0;k<colors.length;k++)if(colors[k].every((v,j)=>Math.abs(v-png.data[i+j])<18))counts[k]++;
  }
  return counts;
}
async function checkData(page){
  const result=await page.evaluate(()=>{
    const p=document.getElementById('plot'),view=JSON.parse(document.getElementById('trajectory-data').textContent).views
      .find(v=>v.id===window.trajectoryState.environment);
    let count=0;
    for(const trace of p.data){
      if(trace.meta.kind==='waypoint')continue;
      const series=view.series.find(s=>s.method===trace.meta.method),points=series[trace.meta.kind];
      if(trace.x.length!==points.length)throw Error('Sample count mismatch');
      points.forEach((xyz,i)=>{
        if(xyz[0]!==trace.x[i]||xyz[1]!==trace.y[i]||xyz[2]!==trace.z[i]||series.t[i]!==trace.customdata[i])throw Error('Coordinates changed');
      });
      count+=points.length;
    }
    for(const name of Object.keys(p.layout).filter(k=>/^scene\d*$/.test(k))){
      for(const [i,axis] of ['xaxis','yaxis','zaxis'].entries()){
        if(JSON.stringify(p.layout[name][axis].range)!==JSON.stringify(view.limits[i]))throw Error('Scene limits differ');
      }
    }
    if(document.documentElement.scrollWidth>innerWidth+1)throw Error('Horizontal overflow');
    const controls=[...document.querySelectorAll('.toolbar label,.toolbar .segmented,.toolbar select')].map(e=>e.getBoundingClientRect());
    for(let i=0;i<controls.length;i++)for(let j=i+1;j<controls.length;j++){
      const a=controls[i],b=controls[j];
      if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>1&&Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>1)throw Error('Toolbar overlaps');
    }
    return {state:trajectoryState,samples:count};
  });
  return result;
}
async function main(){
  const browser=await chromium.launch({channel:'msedge',headless:true,args:['--allow-file-access-from-files']});
  try{
    for(const viewport of [{width:1440,height:900},{width:390,height:844}]){
      const page=await browser.newPage({viewport});
      page.on('pageerror',error=>errors.push(String(error)));
      page.on('request',request=>{if(/^https?:/.test(request.url()))remote.push(request.url());});
      await page.goto(pathToFileURL(path.join(suite,'trajectory_view.html')).href);
      await settled(page);
      for(let env=0;env<5;env++){
        await page.getByRole('tab').nth(env).click();await settled(page);
        for(const arrangement of ['overlay','separate']){
          await click(page,'[data-arrangement='+arrangement+']');
          const check=await checkData(page);
          const pixels=await screenshot(page,viewport.width+'_E'+env+'_'+arrangement+'.png');
          pixels.forEach((n,i)=>assert(n>25,'Blank method '+i+' in E'+env+' '+arrangement+' '+JSON.stringify(pixels)));
          records.push({viewport,environment:env,arrangement,pixels,...check});
        }
      }
      await page.getByRole('tab').nth(0).click();await settled(page);
      for(const scale of ['metric','display']){
        await click(page,'[data-scale='+scale+']');
        assert(await page.evaluate(()=>Object.keys(document.getElementById('plot').layout).filter(k=>/^scene\d*$/.test(k))
          .every(k=>document.getElementById('plot').layout[k].aspectmode===(trajectoryState.scale==='metric'?'data':'manual'))));
      }
      for(const preset of ['top','front','side','oblique']){
        await page.locator('#camera').selectOption(preset);await settled(page);await checkData(page);
      }
      await page.locator('#reference').check();await settled(page);
      assert.equal(await page.evaluate(()=>document.getElementById('plot').data.filter(t=>t.meta.kind==='reference'&&t.visible).length),3);
      await page.locator('#line-width').fill('9');await page.locator('#line-width').dispatchEvent('input');await settled(page);
      assert(await page.evaluate(()=>document.getElementById('plot').data.filter(t=>t.meta.kind==='measured').every(t=>t.line.width===9)));
      for(const solo of ['bezier','hermite','bspline']){
        for(const method of ['bezier','hermite','bspline'])await page.locator('[data-method='+method+']').setChecked(method===solo);
        await settled(page);
        const visible=await page.evaluate(()=>document.getElementById('plot').data.filter(t=>t.meta.kind==='measured'&&t.visible).map(t=>t.meta.method));
        assert.deepEqual(visible,[solo]);
      }
      await page.locator('[data-method=bspline]').uncheck();await settled(page);assert(await page.locator('#empty').isVisible());
      for(const method of ['bezier','hermite','bspline'])await page.locator('[data-method='+method+']').check();
      await page.locator('#reference').uncheck();await settled(page);
      await page.locator('#line-width').fill('6');await page.locator('#line-width').dispatchEvent('input');await settled(page);
      const target=page.locator('#plot #scene canvas').first();await target.scrollIntoViewIfNeeded();
      const rect=await target.boundingBox();
      const x=rect.x+rect.width*.5,y=rect.y+rect.height*.5;
      const before=await page.evaluate(()=>JSON.stringify(document.getElementById('plot').layout.scene.camera.eye));
      await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+55,y+25,{steps:12});await page.mouse.up();
      await page.waitForFunction(value=>JSON.stringify(document.getElementById('plot').layout.scene.camera.eye)!==value,before);await settled(page);
      assert(await page.evaluate(()=>{
        const l=document.getElementById('plot').layout,c=JSON.stringify(l.scene.camera);
        return JSON.stringify(l.scene2.camera)===c&&JSON.stringify(l.scene3.camera)===c;
      }));
      const rotated=await page.evaluate(()=>JSON.stringify(document.getElementById('plot').layout.scene.camera));
      await page.mouse.wheel(0,-180);
      await page.waitForFunction(value=>JSON.stringify(document.getElementById('plot').layout.scene.camera)!==value,rotated);await settled(page);
      const zoomed=await page.evaluate(()=>JSON.stringify(document.getElementById('plot').layout.scene.camera));
      await click(page,'[data-arrangement=overlay]');
      assert.equal(await page.evaluate(()=>JSON.stringify(document.getElementById('plot').layout.scene.camera)),zoomed);
      await page.locator('#camera').selectOption('oblique');await settled(page);
      await screenshot(page,viewport.width+'_interaction_final.png');
      if(viewport.width===1440){
        const [download]=await Promise.all([page.waitForEvent('download'),page.locator('[data-title="Download plot as a PNG"]').click()]);
        await download.saveAs(path.join(output,'current_view_export.png'));
        const image=PNG.sync.read(fs.readFileSync(path.join(output,'current_view_export.png')));
        assert.equal(image.width,1600);assert.equal(image.height,1000);
      }
      // Verify the parent result page grows to include stacked mobile scenes.
      await page.goto(pathToFileURL(path.join(suite,'index.html')).href);
      const child=page.frames().find(f=>f.url().endsWith('/trajectory_view.html'));
      assert(child);await settled(child);await click(child,'[data-arrangement=separate]');
      await page.waitForFunction(()=>{
        const f=document.querySelector('.trajectory-frame');return f.clientHeight>=f.contentDocument.querySelector('main').getBoundingClientRect().height;
      });
      assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
      await screenshot(page,viewport.width+'_suite.png');
      await page.close();
    }
    assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);
    const result={status:'PASS',records,errors,remote,scope:'Offline result-page rendering and interaction; no AirSim or camera data'};
    fs.writeFileSync(path.join(output,'verification.json'),JSON.stringify(result,null,2));
    fs.copyFileSync(__filename,path.join(output,'verify_trajectory_browser.cjs'));
    console.log(JSON.stringify({status:'PASS',views:records.length,errors,remote,output}));
  }finally{await browser.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
