"""Prepare three references or explicitly fly them; default never calls AirSim."""
import argparse
import json
from pathlib import Path

from geometric_validation.campaign import PLANNER_CONFIG, TASK_CONFIG, prepare, run_campaign
from geometric_validation.planners import METHODS
from geometric_validation.runtime import load_config


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--task", type=Path, default=TASK_CONFIG)
    p.add_argument("--config", type=Path, default=PLANNER_CONFIG)
    p.add_argument("--airsim", action="store_true")
    p.add_argument("--launch", action="store_true")
    p.add_argument("--method", choices=METHODS)
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    if a.launch and not a.airsim:
        p.error("--launch requires --airsim")
    if a.prepare:
        prepare(a.task, a.config)
    cfg = load_config(a.config)
    if not a.airsim:
        print(json.dumps(dict(check="PASS", rpc=False, methods=[v["method"] for v in cfg["cases"].values()]), indent=2))
        return 0
    folder, rows = run_campaign(a.config, a.output, [a.method] if a.method else METHODS, a.launch)
    print(json.dumps(dict(directory=str(folder), results=rows), ensure_ascii=False, indent=2))
    return 0 if all(r["accepted"] is True for r in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
