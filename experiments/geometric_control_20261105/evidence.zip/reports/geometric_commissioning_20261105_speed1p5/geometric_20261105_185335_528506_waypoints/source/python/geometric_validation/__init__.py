"""Independent geometric outer-loop validation; no legacy runtime is imported."""

PROTOCOL = "geometric_hybrid_validation_v1"

